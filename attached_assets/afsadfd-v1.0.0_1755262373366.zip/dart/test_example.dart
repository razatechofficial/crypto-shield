import 'dart:io';
import 'package:afsadfd/afsadfd.dart';

void main() async {
  print('Testing afsadfd SDK v1.0.0...');
  
  try {
    // Generate a key
    final key = generateKey();
    print('✓ Key generated successfully');
    
    // Test encryption
    const testData = 'Hello, Averox Crypto System!';
    final encrypted = await encrypt(testData, key);
    print('✓ Encryption successful');
    
    // Test decryption
    final decrypted = await decrypt(encrypted, key);
    print('✓ Decryption successful');
    
    if (decrypted == testData) {
      print('✅ All tests passed! SDK is working correctly.');
      exit(0);
    } else {
      print('❌ Test failed: Decrypted data does not match original');
      exit(1);
    }
  } catch (error) {
    print('❌ Test failed: $error');
    exit(1);
  }
}