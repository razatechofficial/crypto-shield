import 'package:test/test.dart';
import 'package:afsadfd/afsadfd.dart';

void main() {
  group('afsadfd Tests', () {
    late String testKey;
    
    setUp(() {
      testKey = generateKey();
    });
    
    test('should generate valid keys', () {
      final key1 = generateKey();
      final key2 = generateKey();
      
      expect(key1, isNotEmpty);
      expect(key2, isNotEmpty);
      expect(key1, isNot(equals(key2)));
    });
    
    test('should encrypt and decrypt successfully', () async {
      const plaintext = 'Hello, Averox Crypto System!';
      
      final encrypted = await encrypt(plaintext, testKey);
      expect(encrypted, isNotEmpty);
      expect(encrypted, isNot(equals(plaintext)));
      
      final decrypted = await decrypt(encrypted, testKey);
      expect(decrypted, equals(plaintext));
    });
    
    test('should handle AAD correctly', () async {
      const plaintext = 'Secret message with AAD';
      const aad = 'metadata:user123,action:transfer';
      
      final encrypted = await encrypt(plaintext, testKey, aad: aad);
      final decrypted = await decrypt(encrypted, testKey);
      
      expect(decrypted, equals(plaintext));
    });
    
    test('should fail with wrong key', () async {
      const plaintext = 'Secret message';
      final wrongKey = generateKey();
      
      final encrypted = await encrypt(plaintext, testKey);
      
      expect(() async => await decrypt(encrypted, wrongKey), 
             throwsA(isA<Exception>()));
    });
    
    test('should validate input parameters', () async {
      expect(() => encrypt('', testKey), throwsArgumentError);
      expect(() => encrypt('test', ''), throwsArgumentError);
      expect(() => decrypt('', testKey), throwsArgumentError);
    });
  });
}