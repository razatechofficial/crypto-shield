#ifndef AVEROX_CRYPTO_H
#define AVEROX_CRYPTO_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

// Result codes
#define AVEROX_SUCCESS 0
#define AVEROX_ERROR_INVALID_PARAM -1
#define AVEROX_ERROR_CRYPTO_FAIL -2
#define AVEROX_ERROR_MEMORY -3

// Key sizes
#define AVEROX_KEY_SIZE 32
#define AVEROX_IV_SIZE 12
#define AVEROX_TAG_SIZE 16

// Structure definitions
typedef struct {
    uint8_t *data;
    size_t length;
} averox_buffer_t;

typedef struct {
    uint8_t key[AVEROX_KEY_SIZE];
    uint8_t iv[AVEROX_IV_SIZE];
    uint8_t tag[AVEROX_TAG_SIZE];
} averox_crypto_context_t;

// Core API functions
int averox_generate_key(uint8_t *key, size_t key_size);
int averox_encrypt(const uint8_t *plaintext, size_t plaintext_len,
                   const uint8_t *key, size_t key_len,
                   uint8_t *ciphertext, size_t *ciphertext_len,
                   uint8_t *iv, uint8_t *tag);
int averox_encrypt_aad(const uint8_t *plaintext, size_t plaintext_len,
                       const uint8_t *key, size_t key_len,
                       const uint8_t *aad, size_t aad_len,
                       uint8_t *ciphertext, size_t *ciphertext_len,
                       uint8_t *iv, uint8_t *tag);
int averox_decrypt(const uint8_t *ciphertext, size_t ciphertext_len,
                   const uint8_t *key, size_t key_len,
                   const uint8_t *iv, const uint8_t *tag,
                   uint8_t *plaintext, size_t *plaintext_len);
int averox_decrypt_aad(const uint8_t *ciphertext, size_t ciphertext_len,
                       const uint8_t *key, size_t key_len,
                       const uint8_t *iv, const uint8_t *tag,
                       const uint8_t *aad, size_t aad_len,
                       uint8_t *plaintext, size_t *plaintext_len);

// Utility functions
int averox_init(void);
void averox_cleanup(void);
const char *averox_error_string(int error_code);

#ifdef __cplusplus
}
#endif

#endif // AVEROX_CRYPTO_H