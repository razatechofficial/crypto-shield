#include "averox_crypto.h"
#include <string.h>
#include <stdlib.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <openssl/aes.h>

static int g_initialized = 0;

int averox_init(void) {
    if (g_initialized) {
        return AVEROX_SUCCESS;
    }
    
    // Initialize OpenSSL
    OpenSSL_add_all_algorithms();
    g_initialized = 1;
    return AVEROX_SUCCESS;
}

void averox_cleanup(void) {
    if (g_initialized) {
        EVP_cleanup();
        g_initialized = 0;
    }
}

int averox_generate_key(uint8_t *key, size_t key_size) {
    if (!key || key_size != AVEROX_KEY_SIZE) {
        return AVEROX_ERROR_INVALID_PARAM;
    }
    
    if (!g_initialized && averox_init() != AVEROX_SUCCESS) {
        return AVEROX_ERROR_CRYPTO_FAIL;
    }
    
    if (RAND_bytes(key, key_size) != 1) {
        return AVEROX_ERROR_CRYPTO_FAIL;
    }
    
    return AVEROX_SUCCESS;
}

int averox_encrypt(const uint8_t *plaintext, size_t plaintext_len,
                   const uint8_t *key, size_t key_len,
                   uint8_t *ciphertext, size_t *ciphertext_len,
                   uint8_t *iv, uint8_t *tag) {
    
    if (!plaintext || !key || !ciphertext || !ciphertext_len || !iv || !tag) {
        return AVEROX_ERROR_INVALID_PARAM;
    }
    
    if (key_len != AVEROX_KEY_SIZE) {
        return AVEROX_ERROR_INVALID_PARAM;
    }
    
    if (!g_initialized && averox_init() != AVEROX_SUCCESS) {
        return AVEROX_ERROR_CRYPTO_FAIL;
    }
    
    // Generate random IV
    if (RAND_bytes(iv, AVEROX_IV_SIZE) != 1) {
        return AVEROX_ERROR_CRYPTO_FAIL;
    }
    
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (!ctx) {
        return AVEROX_ERROR_MEMORY;
    }
    
    int result = AVEROX_ERROR_CRYPTO_FAIL;
    int len;
    
    do {
        // Initialize encryption with proper IV length setting for interoperability
        if (EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, NULL, NULL) != 1) {
            break;
        }
        
        // Set IV length explicitly for GCM interoperability (critical fix)
        if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, AVEROX_IV_SIZE, NULL) != 1) {
            break;
        }
        
        // Set key and IV
        if (EVP_EncryptInit_ex(ctx, NULL, NULL, key, iv) != 1) {
            break;
        }
        
        // Encrypt data
        if (EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len) != 1) {
            break;
        }
        *ciphertext_len = len;
        
        // Finalize
        if (EVP_EncryptFinal_ex(ctx, ciphertext + len, &len) != 1) {
            break;
        }
        *ciphertext_len += len;
        
        // Get authentication tag
        if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, AVEROX_TAG_SIZE, tag) != 1) {
            break;
        }
        
        result = AVEROX_SUCCESS;
    } while (0);
    
    EVP_CIPHER_CTX_free(ctx);
    return result;
}

int averox_encrypt_aad(const uint8_t *plaintext, size_t plaintext_len,
                       const uint8_t *key, size_t key_len,
                       const uint8_t *aad, size_t aad_len,
                       uint8_t *ciphertext, size_t *ciphertext_len,
                       uint8_t *iv, uint8_t *tag) {
    
    if (!plaintext || !key || !ciphertext || !ciphertext_len || !iv || !tag) {
        return AVEROX_ERROR_INVALID_PARAM;
    }
    
    if (key_len != AVEROX_KEY_SIZE) {
        return AVEROX_ERROR_INVALID_PARAM;
    }
    
    if (!g_initialized && averox_init() != AVEROX_SUCCESS) {
        return AVEROX_ERROR_CRYPTO_FAIL;
    }
    
    // Generate random IV
    if (RAND_bytes(iv, AVEROX_IV_SIZE) != 1) {
        return AVEROX_ERROR_CRYPTO_FAIL;
    }
    
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (!ctx) {
        return AVEROX_ERROR_MEMORY;
    }
    
    int result = AVEROX_ERROR_CRYPTO_FAIL;
    int len;
    
    do {
        // Initialize encryption with proper IV length setting for interoperability
        if (EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, NULL, NULL) != 1) {
            break;
        }
        
        // Set IV length explicitly for GCM interoperability (critical fix)
        if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, AVEROX_IV_SIZE, NULL) != 1) {
            break;
        }
        
        // Set key and IV
        if (EVP_EncryptInit_ex(ctx, NULL, NULL, key, iv) != 1) {
            break;
        }
        
        // Process AAD if provided
        if (aad && aad_len > 0) {
            if (EVP_EncryptUpdate(ctx, NULL, &len, aad, aad_len) != 1) {
                break;
            }
        }
        
        // Encrypt data
        if (EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len) != 1) {
            break;
        }
        *ciphertext_len = len;
        
        // Finalize
        if (EVP_EncryptFinal_ex(ctx, ciphertext + len, &len) != 1) {
            break;
        }
        *ciphertext_len += len;
        
        // Get authentication tag
        if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, AVEROX_TAG_SIZE, tag) != 1) {
            break;
        }
        
        result = AVEROX_SUCCESS;
    } while (0);
    
    EVP_CIPHER_CTX_free(ctx);
    return result;
}

int averox_decrypt(const uint8_t *ciphertext, size_t ciphertext_len,
                   const uint8_t *key, size_t key_len,
                   const uint8_t *iv, const uint8_t *tag,
                   uint8_t *plaintext, size_t *plaintext_len) {
    
    if (!ciphertext || !key || !iv || !tag || !plaintext || !plaintext_len) {
        return AVEROX_ERROR_INVALID_PARAM;
    }
    
    if (key_len != AVEROX_KEY_SIZE) {
        return AVEROX_ERROR_INVALID_PARAM;
    }
    
    if (!g_initialized && averox_init() != AVEROX_SUCCESS) {
        return AVEROX_ERROR_CRYPTO_FAIL;
    }
    
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (!ctx) {
        return AVEROX_ERROR_MEMORY;
    }
    
    int result = AVEROX_ERROR_CRYPTO_FAIL;
    int len;
    
    do {
        // Initialize decryption with proper IV length setting for interoperability
        if (EVP_DecryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, NULL, NULL) != 1) {
            break;
        }
        
        // Set IV length explicitly for GCM interoperability (critical fix)
        if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, AVEROX_IV_SIZE, NULL) != 1) {
            break;
        }
        
        // Set key and IV
        if (EVP_DecryptInit_ex(ctx, NULL, NULL, key, iv) != 1) {
            break;
        }
        
        // Decrypt data
        if (EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len) != 1) {
            break;
        }
        *plaintext_len = len;
        
        // Set expected tag
        if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_TAG, AVEROX_TAG_SIZE, (void*)tag) != 1) {
            break;
        }
        
        // Finalize and verify tag
        if (EVP_DecryptFinal_ex(ctx, plaintext + len, &len) != 1) {
            break;
        }
        *plaintext_len += len;
        
        result = AVEROX_SUCCESS;
    } while (0);
    
    EVP_CIPHER_CTX_free(ctx);
    return result;
}

int averox_decrypt_aad(const uint8_t *ciphertext, size_t ciphertext_len,
                       const uint8_t *key, size_t key_len,
                       const uint8_t *iv, const uint8_t *tag,
                       const uint8_t *aad, size_t aad_len,
                       uint8_t *plaintext, size_t *plaintext_len) {
    
    if (!ciphertext || !key || !iv || !tag || !plaintext || !plaintext_len) {
        return AVEROX_ERROR_INVALID_PARAM;
    }
    
    if (key_len != AVEROX_KEY_SIZE) {
        return AVEROX_ERROR_INVALID_PARAM;
    }
    
    if (!g_initialized && averox_init() != AVEROX_SUCCESS) {
        return AVEROX_ERROR_CRYPTO_FAIL;
    }
    
    EVP_CIPHER_CTX *ctx = EVP_CIPHER_CTX_new();
    if (!ctx) {
        return AVEROX_ERROR_MEMORY;
    }
    
    int result = AVEROX_ERROR_CRYPTO_FAIL;
    int len;
    
    do {
        // Initialize decryption with proper IV length setting for interoperability
        if (EVP_DecryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, NULL, NULL) != 1) {
            break;
        }
        
        // Set IV length explicitly for GCM interoperability (critical fix)
        if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, AVEROX_IV_SIZE, NULL) != 1) {
            break;
        }
        
        // Set key and IV
        if (EVP_DecryptInit_ex(ctx, NULL, NULL, key, iv) != 1) {
            break;
        }
        
        // Process AAD if provided
        if (aad && aad_len > 0) {
            if (EVP_DecryptUpdate(ctx, NULL, &len, aad, aad_len) != 1) {
                break;
            }
        }
        
        // Decrypt data
        if (EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len) != 1) {
            break;
        }
        *plaintext_len = len;
        
        // Set expected tag
        if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_TAG, AVEROX_TAG_SIZE, (void*)tag) != 1) {
            break;
        }
        
        // Finalize and verify tag
        if (EVP_DecryptFinal_ex(ctx, plaintext + len, &len) != 1) {
            break;
        }
        *plaintext_len += len;
        
        result = AVEROX_SUCCESS;
    } while (0);
    
    EVP_CIPHER_CTX_free(ctx);
    return result;
}

const char *averox_error_string(int error_code) {
    switch (error_code) {
        case AVEROX_SUCCESS: return "Success";
        case AVEROX_ERROR_INVALID_PARAM: return "Invalid parameter";
        case AVEROX_ERROR_CRYPTO_FAIL: return "Cryptographic operation failed";
        case AVEROX_ERROR_MEMORY: return "Memory allocation failed";
        default: return "Unknown error";
    }
}