#include "averox_crypto.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main() {
    printf("afsadfd SDK v1.0.0 - C Example\n");
    
    // Initialize
    if (averox_init() != AVEROX_SUCCESS) {
        fprintf(stderr, "Failed to initialize Averox SDK\n");
        return 1;
    }
    
    // Generate key
    uint8_t key[AVEROX_KEY_SIZE];
    if (averox_generate_key(key, sizeof(key)) != AVEROX_SUCCESS) {
        fprintf(stderr, "Failed to generate key\n");
        return 1;
    }
    
    // Test data
    const char *test_data = "Hello, Averox Crypto System!";
    size_t data_len = strlen(test_data);
    
    // Encrypt (the encrypt function will generate a random IV)
    uint8_t ciphertext[1024];
    size_t ciphertext_len;
    uint8_t iv[AVEROX_IV_SIZE];  // Will be populated by averox_encrypt
    uint8_t tag[AVEROX_TAG_SIZE]; // Will be populated by averox_encrypt
    
    printf("Encrypting data: '%s'\n", test_data);
    int result = averox_encrypt((const uint8_t*)test_data, data_len,
                               key, sizeof(key),
                               ciphertext, &ciphertext_len,
                               iv, tag);
    
    if (result != AVEROX_SUCCESS) {
        fprintf(stderr, "Encryption failed: %s\n", averox_error_string(result));
        return 1;
    }
    
    printf("✓ Encryption successful\n");
    
    // Decrypt
    uint8_t plaintext[1024];
    size_t plaintext_len;
    
    result = averox_decrypt(ciphertext, ciphertext_len,
                           key, sizeof(key),
                           iv, tag,
                           plaintext, &plaintext_len);
    
    if (result != AVEROX_SUCCESS) {
        fprintf(stderr, "Decryption failed: %s\n", averox_error_string(result));
        return 1;
    }
    
    // Verify
    plaintext[plaintext_len] = '\0';
    if (strcmp((char*)plaintext, test_data) == 0) {
        printf("✅ Test passed! Decrypted: %s\n", (char*)plaintext);
    } else {
        printf("❌ Test failed! Got: %s\n", (char*)plaintext);
        return 1;
    }
    
    averox_cleanup();
    return 0;
}