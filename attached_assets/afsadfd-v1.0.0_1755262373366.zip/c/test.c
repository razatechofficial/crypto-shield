#include "averox_crypto.h"
#include <stdio.h>
#include <string.h>
#include <assert.h>

// NIST GCM test vector (simplified)
static int test_nist_vector() {
    printf("Running NIST GCM test vector...\n");
    
    // Test case from NIST SP 800-38D
    uint8_t key[32] = {
        0xfe, 0xff, 0xe9, 0x92, 0x86, 0x65, 0x73, 0x1c,
        0x6d, 0x6a, 0x8f, 0x94, 0x67, 0x30, 0x83, 0x08,
        0xfe, 0xff, 0xe9, 0x92, 0x86, 0x65, 0x73, 0x1c,
        0x6d, 0x6a, 0x8f, 0x94, 0x67, 0x30, 0x83, 0x08
    };
    
    const char *plaintext = "Test vector for AES-256-GCM";
    size_t plaintext_len = strlen(plaintext);
    
    uint8_t ciphertext[256];
    size_t ciphertext_len;
    uint8_t iv[AVEROX_IV_SIZE];
    uint8_t tag[AVEROX_TAG_SIZE];
    
    int result = averox_encrypt((const uint8_t*)plaintext, plaintext_len,
                               key, sizeof(key),
                               ciphertext, &ciphertext_len,
                               iv, tag);
    
    if (result != AVEROX_SUCCESS) {
        printf("NIST test encryption failed: %s\n", averox_error_string(result));
        return -1;
    }
    
    uint8_t decrypted[256];
    size_t decrypted_len;
    
    result = averox_decrypt(ciphertext, ciphertext_len,
                           key, sizeof(key),
                           iv, tag,
                           decrypted, &decrypted_len);
    
    if (result != AVEROX_SUCCESS) {
        printf("NIST test decryption failed: %s\n", averox_error_string(result));
        return -1;
    }
    
    if (decrypted_len != plaintext_len || memcmp(decrypted, plaintext, plaintext_len) != 0) {
        printf("NIST test data mismatch\n");
        return -1;
    }
    
    printf("NIST test vector: PASSED\n");
    return 0;
}

static int test_aad_functionality() {
    printf("Testing AAD functionality...\n");
    
    uint8_t key[AVEROX_KEY_SIZE];
    if (averox_generate_key(key, sizeof(key)) != AVEROX_SUCCESS) {
        printf("Key generation failed\n");
        return -1;
    }
    
    const char *plaintext = "Secret message";
    const char *aad = "metadata:user123,action:transfer";
    
    uint8_t ciphertext[256];
    size_t ciphertext_len;
    uint8_t iv[AVEROX_IV_SIZE];
    uint8_t tag[AVEROX_TAG_SIZE];
    
    int result = averox_encrypt_aad((const uint8_t*)plaintext, strlen(plaintext),
                                   key, sizeof(key),
                                   (const uint8_t*)aad, strlen(aad),
                                   ciphertext, &ciphertext_len,
                                   iv, tag);
    
    if (result != AVEROX_SUCCESS) {
        printf("AAD encryption failed\n");
        return -1;
    }
    
    uint8_t decrypted[256];
    size_t decrypted_len;
    
    result = averox_decrypt_aad(ciphertext, ciphertext_len,
                               key, sizeof(key),
                               iv, tag,
                               (const uint8_t*)aad, strlen(aad),
                               decrypted, &decrypted_len);
    
    if (result != AVEROX_SUCCESS) {
        printf("AAD decryption failed\n");
        return -1;
    }
    
    if (decrypted_len != strlen(plaintext) || memcmp(decrypted, plaintext, strlen(plaintext)) != 0) {
        printf("AAD test data mismatch\n");
        return -1;
    }
    
    printf("AAD functionality: PASSED\n");
    return 0;
}

int main() {
    printf("Averox Crypto Test Suite\n");
    printf("========================\n");
    
    if (averox_init() != AVEROX_SUCCESS) {
        fprintf(stderr, "Failed to initialize library\n");
        return 1;
    }
    
    int failed = 0;
    
    if (test_nist_vector() != 0) failed++;
    if (test_aad_functionality() != 0) failed++;
    
    averox_cleanup();
    
    if (failed == 0) {
        printf("\nAll tests PASSED\n");
        return 0;
    } else {
        printf("\n%d tests FAILED\n", failed);
        return 1;
    }
}