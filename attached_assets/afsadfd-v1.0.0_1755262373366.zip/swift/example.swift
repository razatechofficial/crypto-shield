import Foundation
import afsadfdSDK

print("Testing afsadfd SDK v1.0.0...")

do {
    // Generate a key
    let key = generateKey()
    print("✓ Key generated successfully")
    
    // Test encryption
    let testData = "Hello, Averox Crypto System!"
    let encrypted = try encrypt(testData, key: key)
    print("✓ Encryption successful")
    
    // Test decryption
    let decrypted = try decrypt(encrypted, key: key)
    print("✓ Decryption successful")
    
    if decrypted == testData {
        print("✅ All tests passed! SDK is working correctly.")
        exit(0)
    } else {
        print("❌ Test failed: Decrypted data does not match original")
        exit(1)
    }
} catch {
    print("❌ Test failed: \(error)")
    exit(1)
}