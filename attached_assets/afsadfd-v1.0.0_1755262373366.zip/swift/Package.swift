// swift-tools-version: 5.7
import PackageDescription

let package = Package(
    name: "afsadfdSDK",
    platforms: [
        .iOS(.v13),
        .macOS(.v10_15),
        .watchOS(.v6),
        .tvOS(.v13)
    ],
    products: [
        .library(
            name: "afsadfdSDK",
            targets: ["afsadfdSDK"]),
    ],
    dependencies: [],
    targets: [
        .target(
            name: "afsadfdSDK",
            dependencies: []),
        .testTarget(
            name: "afsadfdSDKTests",
            dependencies: ["afsadfdSDK"]),
    ]
)