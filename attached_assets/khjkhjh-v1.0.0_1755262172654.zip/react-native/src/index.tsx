import { NativeModules, Platform } from 'react-native';

const LINKING_ERROR =
  "The package 'khjkhjh-react-native' doesn't seem to be linked. Make sure: \n\n" +
  Platform.select({ ios: "- You have run 'pod install'\n", default: '' }) +
  '- You rebuilt the app after installing the package\n' +
  '- You are not using Expo managed workflow\n';

const AveroxCrypto = NativeModules.AveroxCrypto
  ? NativeModules.AveroxCrypto
  : new Proxy(
      {},
      {
        get() {
          throw new Error(LINKING_ERROR);
        },
      }
    );

export interface CryptoResult {
  success: boolean;
  data?: string;
  error?: string;
}

export interface EncryptionResult extends CryptoResult {
  data?: string; // Base64 encoded encrypted data with IV and tag
}

export interface DecryptionResult extends CryptoResult {
  data?: string; // Decrypted plaintext
}

export class AveroxSDK {
  /**
   * Generate a cryptographically secure key
   * @returns Promise<string> Base64 encoded key
   */
  static async generateKey(): Promise<string> {
    try {
      const result = await AveroxCrypto.generateKey();
      if (result.success) {
        return result.data;
      }
      throw new Error(result.error || 'Key generation failed');
    } catch (error) {
      throw new Error(`Key generation failed: ${error}`);
    }
  }

  /**
   * Encrypt data using AES-256-GCM
   * @param data - Data to encrypt
   * @param key - Base64 encoded key
   * @returns Promise<string> Base64 encoded encrypted data
   */
  static async encrypt(data: string, key: string): Promise<string> {
    try {
      const result = await AveroxCrypto.encrypt(data, key);
      if (result.success) {
        return result.data;
      }
      throw new Error(result.error || 'Encryption failed');
    } catch (error) {
      throw new Error(`Encryption failed: ${error}`);
    }
  }

  /**
   * Decrypt data
   * @param encryptedData - Base64 encoded encrypted data
   * @param key - Base64 encoded key
   * @returns Promise<string> Decrypted plaintext
   */
  static async decrypt(encryptedData: string, key: string): Promise<string> {
    try {
      const result = await AveroxCrypto.decrypt(encryptedData, key);
      if (result.success) {
        return result.data;
      }
      throw new Error(result.error || 'Decryption failed');
    } catch (error) {
      throw new Error(`Decryption failed: ${error}`);
    }
  }

  /**
   * Get SDK version
   */
  static getVersion(): string {
    return '1.0.0';
  }

  /**
   * Get supported algorithms
   */
  static getSupportedAlgorithms(): string[] {
    return ["RSA-2048","RSA-4096","SHA-3-256"];
  }
}

// Convenience functions
export const encrypt = AveroxSDK.encrypt;
export const decrypt = AveroxSDK.decrypt;
export const generateKey = AveroxSDK.generateKey;

export default AveroxSDK;