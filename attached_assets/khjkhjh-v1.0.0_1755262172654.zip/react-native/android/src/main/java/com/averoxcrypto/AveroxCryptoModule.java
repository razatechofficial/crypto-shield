package com.averoxcrypto;

import androidx.annotation.NonNull;

import com.facebook.react.bridge.Promise;
import com.facebook.react.bridge.ReactApplicationContext;
import com.facebook.react.bridge.ReactContextBaseJavaModule;
import com.facebook.react.bridge.ReactMethod;
import com.facebook.react.bridge.WritableMap;
import com.facebook.react.bridge.Arguments;
import com.facebook.react.module.annotations.ReactModule;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.spec.GCMParameterSpec;
import java.security.SecureRandom;
import java.util.Base64;
import org.json.JSONObject;

@ReactModule(name = AveroxCryptoModule.NAME)
public class AveroxCryptoModule extends ReactContextBaseJavaModule {
    public static final String NAME = "AveroxCrypto";
    
    private static final String ALGORITHM = "AES";
    private static final String TRANSFORMATION = "AES/GCM/NoPadding";
    private static final int KEY_SIZE = 256;
    private static final int IV_SIZE = 12;
    private static final int TAG_SIZE = 128;

    public AveroxCryptoModule(ReactApplicationContext reactContext) {
        super(reactContext);
    }

    @Override
    @NonNull
    public String getName() {
        return NAME;
    }

    @ReactMethod
    public void generateKey(Promise promise) {
        try {
            KeyGenerator keyGenerator = KeyGenerator.getInstance(ALGORITHM);
            keyGenerator.init(KEY_SIZE);
            byte[] keyBytes = keyGenerator.generateKey().getEncoded();
            String base64Key = Base64.getEncoder().encodeToString(keyBytes);
            
            WritableMap result = Arguments.createMap();
            result.putBoolean("success", true);
            result.putString("data", base64Key);
            promise.resolve(result);
        } catch (Exception e) {
            WritableMap result = Arguments.createMap();
            result.putBoolean("success", false);
            result.putString("error", e.getMessage());
            promise.resolve(result);
        }
    }

    @ReactMethod
    public void encrypt(String data, String key, Promise promise) {
        try {
            byte[] keyBytes = Base64.getDecoder().decode(key);
            SecretKeySpec secretKey = new SecretKeySpec(keyBytes, ALGORITHM);
            
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            
            // Generate random IV
            byte[] iv = new byte[IV_SIZE];
            new SecureRandom().nextBytes(iv);
            GCMParameterSpec gcmSpec = new GCMParameterSpec(TAG_SIZE, iv);
            
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, gcmSpec);
            byte[] encrypted = cipher.doFinal(data.getBytes());
            
            // Combine IV + encrypted data + tag
            JSONObject result = new JSONObject();
            result.put("data", Base64.getEncoder().encodeToString(encrypted));
            result.put("iv", Base64.getEncoder().encodeToString(iv));
            result.put("algorithm", "aes-256-gcm");
            
            String base64Result = Base64.getEncoder().encodeToString(result.toString().getBytes());
            
            WritableMap response = Arguments.createMap();
            response.putBoolean("success", true);
            response.putString("data", base64Result);
            promise.resolve(response);
        } catch (Exception e) {
            WritableMap response = Arguments.createMap();
            response.putBoolean("success", false);
            response.putString("error", e.getMessage());
            promise.resolve(response);
        }
    }

    @ReactMethod
    public void decrypt(String encryptedData, String key, Promise promise) {
        try {
            byte[] keyBytes = Base64.getDecoder().decode(key);
            SecretKeySpec secretKey = new SecretKeySpec(keyBytes, ALGORITHM);
            
            // Parse encrypted data
            String jsonStr = new String(Base64.getDecoder().decode(encryptedData));
            JSONObject jsonObj = new JSONObject(jsonStr);
            
            byte[] encrypted = Base64.getDecoder().decode(jsonObj.getString("data"));
            byte[] iv = Base64.getDecoder().decode(jsonObj.getString("iv"));
            
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            GCMParameterSpec gcmSpec = new GCMParameterSpec(TAG_SIZE, iv);
            cipher.init(Cipher.DECRYPT_MODE, secretKey, gcmSpec);
            
            byte[] decrypted = cipher.doFinal(encrypted);
            String plaintext = new String(decrypted);
            
            WritableMap response = Arguments.createMap();
            response.putBoolean("success", true);
            response.putString("data", plaintext);
            promise.resolve(response);
        } catch (Exception e) {
            WritableMap response = Arguments.createMap();
            response.putBoolean("success", false);
            response.putString("error", e.getMessage());
            promise.resolve(response);
        }
    }
}