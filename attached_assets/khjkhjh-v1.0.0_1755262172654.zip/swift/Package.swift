// swift-tools-version: 5.7
import PackageDescription

let package = Package(
    name: "khjkhjhSDK",
    platforms: [
        .iOS(.v13),
        .macOS(.v10_15),
        .watchOS(.v6),
        .tvOS(.v13)
    ],
    products: [
        .library(
            name: "khjkhjhSDK",
            targets: ["khjkhjhSDK"]),
    ],
    dependencies: [],
    targets: [
        .target(
            name: "khjkhjhSDK",
            dependencies: []),
        .testTarget(
            name: "khjkhjhSDKTests",
            dependencies: ["khjkhjhSDK"]),
    ]
)