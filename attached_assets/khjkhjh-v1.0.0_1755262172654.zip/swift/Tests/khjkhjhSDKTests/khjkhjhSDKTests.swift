import XCTest
@testable import khjkhjhSDK

final class khjkhjhSDKTests: XCTestCase {
    var testKey: String!
    
    override func setUp() {
        super.setUp()
        testKey = generateKey()
    }
    
    func testKeyGeneration() {
        let key1 = generateKey()
        let key2 = generateKey()
        
        XCTAssertFalse(key1.isEmpty)
        XCTAssertFalse(key2.isEmpty)
        XCTAssertNotEqual(key1, key2)
    }
    
    func testEncryptionDecryption() throws {
        let plaintext = "Hello, Averox Crypto System!"
        
        let encrypted = try encrypt(plaintext, key: testKey)
        XCTAssertFalse(encrypted.isEmpty)
        XCTAssertNotEqual(encrypted, plaintext)
        
        let decrypted = try decrypt(encrypted, key: testKey)
        XCTAssertEqual(decrypted, plaintext)
    }
    
    func testAADSupport() throws {
        let plaintext = "Secret message with AAD"
        let aad = "metadata:user123,action:transfer"
        
        let encrypted = try encrypt(plaintext, key: testKey, aad: aad)
        let decrypted = try decrypt(encrypted, key: testKey)
        
        XCTAssertEqual(decrypted, plaintext)
    }
    
    func testWrongKeyFailure() throws {
        let plaintext = "Secret message"
        let wrongKey = generateKey()
        
        let encrypted = try encrypt(plaintext, key: testKey)
        
        XCTAssertThrowsError(try decrypt(encrypted, key: wrongKey))
    }
    
    func testInputValidation() {
        XCTAssertThrowsError(try encrypt("", key: testKey))
        XCTAssertThrowsError(try encrypt("test", key: ""))
        XCTAssertThrowsError(try decrypt("", key: testKey))
    }
    
    func testUnicodeSupport() throws {
        let plaintext = "Hello 🌟 世界 🔐"
        
        let encrypted = try encrypt(plaintext, key: testKey)
        let decrypted = try decrypt(encrypted, key: testKey)
        
        XCTAssertEqual(decrypted, plaintext)
    }
}