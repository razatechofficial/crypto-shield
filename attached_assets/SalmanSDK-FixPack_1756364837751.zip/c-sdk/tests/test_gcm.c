#include <stdio.h>
#include <string.h>
#include "sdk/aead.h"
int main(){
  uint8_t key[SDK_KEY_LEN]; for(size_t i=0;i<SDK_KEY_LEN;i++) key[i]=(uint8_t)i;
  const char* msg="hello world"; uint8_t iv[SDK_IV_LEN], tag[SDK_TAG_LEN];
  uint8_t ct[256]={0}, pt[256]={0}, aad[]={1,2,3,4};
  if(sdk_aesgcm_encrypt(key,(const uint8_t*)msg,strlen(msg),aad,sizeof(aad),iv,ct,tag)!=SDK_OK) return 1;
  if(sdk_aesgcm_decrypt(key,ct,strlen(msg),aad,sizeof(aad),iv,tag,pt)!=SDK_OK) return 2;
  if(memcmp(msg,pt,strlen(msg))!=0) return 3;
  puts("OK"); return 0;
}
