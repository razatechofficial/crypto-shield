#pragma once
#include <stddef.h>
#include <stdint.h>
#define SDK_KEY_LEN 32
#define SDK_IV_LEN 12
#define SDK_TAG_LEN 16
typedef enum { SDK_OK=0, SDK_ERR_BADINPUT=-1, SDK_ERR_CRYPTO=-2, SDK_ERR_INVALID_TAG=-3 } sdk_status;
sdk_status sdk_aesgcm_encrypt(const uint8_t* key, const uint8_t* pt, size_t pt_len,
                              const uint8_t* aad, size_t aad_len,
                              uint8_t* iv_out, uint8_t* ct_out, uint8_t* tag_out);
sdk_status sdk_aesgcm_decrypt(const uint8_t* key, const uint8_t* ct, size_t ct_len,
                              const uint8_t* aad, size_t aad_len,
                              const uint8_t* iv, const uint8_t* tag,
                              uint8_t* pt_out);
