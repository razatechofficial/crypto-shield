#include <openssl/evp.h>
#include <openssl/rand.h>
#include <string.h>
#include "sdk/aead.h"

sdk_status sdk_aesgcm_encrypt(const uint8_t* key, const uint8_t* pt, size_t pt_len,
                              const uint8_t* aad, size_t aad_len,
                              uint8_t* iv_out, uint8_t* ct_out, uint8_t* tag_out){
  if (!key || !pt || !iv_out || !ct_out || !tag_out) return SDK_ERR_BADINPUT;
  if (RAND_bytes(iv_out, SDK_IV_LEN) != 1) return SDK_ERR_CRYPTO;
  int len=0, outlen=0;
  EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new(); if (!ctx) return SDK_ERR_CRYPTO;
  if (EVP_EncryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, NULL, NULL) != 1) goto err;
  if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, SDK_IV_LEN, NULL) != 1) goto err;
  if (EVP_EncryptInit_ex(ctx, NULL, NULL, key, iv_out) != 1) goto err;
  if (aad && aad_len) { if (EVP_EncryptUpdate(ctx, NULL, &len, aad, (int)aad_len) != 1) goto err; }
  if (EVP_EncryptUpdate(ctx, ct_out, &len, pt, (int)pt_len) != 1) goto err; outlen = len;
  if (EVP_EncryptFinal_ex(ctx, ct_out + outlen, &len) != 1) goto err; outlen += len;
  if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_GET_TAG, SDK_TAG_LEN, tag_out) != 1) goto err;
  EVP_CIPHER_CTX_free(ctx); return SDK_OK;
err: EVP_CIPHER_CTX_free(ctx); return SDK_ERR_CRYPTO;
}

sdk_status sdk_aesgcm_decrypt(const uint8_t* key, const uint8_t* ct, size_t ct_len,
                              const uint8_t* aad, size_t aad_len,
                              const uint8_t* iv, const uint8_t* tag,
                              uint8_t* pt_out){
  if (!key || !ct || !iv || !tag || !pt_out) return SDK_ERR_BADINPUT;
  int len=0, outlen=0;
  EVP_CIPHER_CTX* ctx = EVP_CIPHER_CTX_new(); if (!ctx) return SDK_ERR_CRYPTO;
  if (EVP_DecryptInit_ex(ctx, EVP_aes_256_gcm(), NULL, NULL, NULL) != 1) goto err;
  if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_IVLEN, SDK_IV_LEN, NULL) != 1) goto err;
  if (EVP_DecryptInit_ex(ctx, NULL, NULL, key, iv) != 1) goto err;
  if (aad && aad_len) { if (EVP_DecryptUpdate(ctx, NULL, &len, aad, (int)aad_len) != 1) goto err; }
  if (EVP_DecryptUpdate(ctx, pt_out, &len, ct, (int)ct_len) != 1) goto err; outlen = len;
  if (EVP_CIPHER_CTX_ctrl(ctx, EVP_CTRL_GCM_SET_TAG, SDK_TAG_LEN, (void*)tag) != 1) goto err;
  if (EVP_DecryptFinal_ex(ctx, pt_out + outlen, &len) != 1) { EVP_CIPHER_CTX_free(ctx); return SDK_ERR_INVALID_TAG; }
  EVP_CIPHER_CTX_free(ctx); (void)outlen; return SDK_OK;
}
