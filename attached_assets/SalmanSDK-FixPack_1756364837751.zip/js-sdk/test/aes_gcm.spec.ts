import { encrypt, decrypt, generateKey } from '../src/index';

test('roundtrip with AAD', async () => {
  const key = generateKey();
  const aad = new TextEncoder().encode('audit-header');
  const pt  = new TextEncoder().encode('hello world');
  const env = await encrypt(pt, key, { aad, kid: 'demo' });
  const out = await decrypt(env, key, { aad, expectKid: 'demo' });
  expect(new TextDecoder().decode(out)).toBe('hello world');
});

test('AAD mismatch rejects', async () => {
  const key = generateKey();
  const pt  = new TextEncoder().encode('msg');
  const env = await encrypt(pt, key, { aad: new TextEncoder().encode('A') });
  await expect(decrypt(env, key, { aad: new TextEncoder().encode('B') })).rejects.toBeInstanceOf(Error);
});
