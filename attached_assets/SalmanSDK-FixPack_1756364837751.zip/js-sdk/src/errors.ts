export class InvalidTagError extends Error { constructor(msg='Invalid authentication tag'){super(msg);this.name='InvalidTagError';} }
export class BadInputError extends Error { constructor(msg='Bad input'){super(msg);this.name='BadInputError';} }
