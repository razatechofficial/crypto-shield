import { Envelope, parse } from './envelope';
import { b64uEncode, b64uDecode } from './base64url';
import { InvalidTagError, BadInputError } from './errors';

export type EncryptOpts = { aad?: Uint8Array; kid?: string };
export type DecryptOpts = { aad?: Uint8Array; expectKid?: string };

const isNode = typeof process !== 'undefined' && !!(process.versions && process.versions.node);

function randomBytes(n: number): Uint8Array {
  if (isNode) {
    const { randomBytes } = require('crypto'); // CJS path
    return randomBytes(n);
  }
  const b = new Uint8Array(n); crypto.getRandomValues(b); return b;
}

export function generateKey(): Uint8Array { return randomBytes(32); }

async function encryptNode(pt: Uint8Array, key: Uint8Array, iv: Uint8Array, aad?: Uint8Array) {
  const crypto = await import('crypto');
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv, { authTagLength: 16 });
  if (aad && aad.length) cipher.setAAD(aad, { plaintextLength: pt.length });
  const ct = Buffer.concat([cipher.update(pt), cipher.final()]);
  const tag = cipher.getAuthTag();
  return { ct: new Uint8Array(ct), tag: new Uint8Array(tag) };
}
async function decryptNode(env: Envelope, key: Uint8Array, aad?: Uint8Array) {
  const crypto = await import('crypto');
  const iv = b64uDecode(env.iv), tag = b64uDecode(env.tag), ct = b64uDecode(env.ct);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv, { authTagLength: 16 });
  if (aad && aad.length) decipher.setAAD(aad, { plaintextLength: ct.length });
  decipher.setAuthTag(Buffer.from(tag));
  try {
    const pt = Buffer.concat([decipher.update(ct), decipher.final()]);
    return new Uint8Array(pt);
  } catch { throw new InvalidTagError(); }
}
async function encryptWeb(pt: Uint8Array, key: Uint8Array, iv: Uint8Array, aad?: Uint8Array) {
  const cryptoKey = await crypto.subtle.importKey('raw', key, 'AES-GCM', false, ['encrypt']);
  const buf = await crypto.subtle.encrypt({ name: 'AES-GCM', iv, additionalData: aad, tagLength: 128 }, cryptoKey, pt);
  const u = new Uint8Array(buf);
  const ct = u.slice(0, u.length - 16);
  const tag = u.slice(u.length - 16);
  return { ct, tag };
}
async function decryptWeb(env: Envelope, key: Uint8Array, aad?: Uint8Array) {
  const iv = b64uDecode(env.iv), tag = b64uDecode(env.tag), ct = b64uDecode(env.ct);
  const cryptoKey = await crypto.subtle.importKey('raw', key, 'AES-GCM', false, ['decrypt']);
  const buf = new Uint8Array(ct.length + tag.length); buf.set(ct,0); buf.set(tag,ct.length);
  try {
    const out = await crypto.subtle.decrypt({ name: 'AES-GCM', iv, additionalData: aad, tagLength: 128 }, cryptoKey, buf);
    return new Uint8Array(out);
  } catch { throw new InvalidTagError(); }
}

export async function encrypt(plaintext: Uint8Array, key: Uint8Array, opts: EncryptOpts = {}): Promise<string> {
  if (!key || key.length !== 32) throw new BadInputError('Key must be 32 bytes for AES-256-GCM');
  const iv = randomBytes(12);
  const impl = isNode ? encryptNode : encryptWeb;
  const { ct, tag } = await impl(plaintext, key, iv, opts.aad);
  const env: Envelope = { v:'2', alg:'AES-256-GCM', kid: opts.kid, iv: b64uEncode(iv), tag: b64uEncode(tag), ct: b64uEncode(ct) };
  return JSON.stringify(env);
}
export async function decrypt(envelope: string, key: Uint8Array, opts: DecryptOpts = {}): Promise<Uint8Array> {
  if (!key || key.length !== 32) throw new BadInputError('Key must be 32 bytes for AES-256-GCM');
  const env = parse(envelope);
  if (opts.expectKid && env.kid !== opts.expectKid) throw new BadInputError('KID mismatch');
  const impl = isNode ? decryptNode : decryptWeb;
  return impl(env, key, opts.aad);
}
