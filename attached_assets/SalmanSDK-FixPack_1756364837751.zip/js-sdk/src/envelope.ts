export type Envelope = { v:'2'; alg:'AES-256-GCM'; kid?:string; iv:string; tag:string; ct:string };
export function parse(s: string): Envelope {
  const o = JSON.parse(s);
  if (o.v !== '2') throw new Error('Unsupported envelope version');
  if (o.alg !== 'AES-256-GCM') throw new Error('Unsupported algorithm');
  for (const k of ['iv','tag','ct']) if (typeof o[k] !== 'string') throw new Error('Malformed envelope');
  return o;
}
