# Security Overview
- 12-byte IVs, generated internally.
- AAD support; mismatches cause auth failure.
- JS uses WebCrypto/Node crypto; C uses OpenSSL EVP with explicit IV len and tag APIs.
- No secret logging; minimal, auditable surface.
