# Salman Crypto Fix Pack
Production-grade AES-256-GCM with AAD and a canonical JSON envelope.
## Envelope
```json
{"v":"2","alg":"AES-256-GCM","kid":"...","iv":"<b64url>","tag":"<b64url>","ct":"<b64url>"}
```
## JS quickstart
```bash
cd js-sdk && npm i && npm run build && npm test
```
## C quickstart
```bash
cmake -S c-sdk -B build -DSAN=ON
cmake --build build -j
ctest --test-dir build --output-on-failure
```
