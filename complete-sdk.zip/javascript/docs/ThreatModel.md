# Threat Model

## Assets

- **Encryption Keys**: Master keys, derived keys, temporary key material
- **Plaintext Data**: User data before encryption  
- **Ciphertext Data**: Encrypted data with authentication tags
- **Authentication Tags**: AES-GCM authentication tags for integrity
- **Key Derivation Material**: HKDF inputs, salts, and intermediate values

## Trust Boundaries

- **Application boundary**: Between user application and SDK
- **Platform boundary**: Between SDK and operating system/hardware
- **Network boundary**: Between encrypted data and transmission medium

## STRIDE Analysis

| Threat | Description | Mitigations | Residual Risk |
|--------|-------------|-------------|---------------|
| **Spoofing** | Attacker impersonates legitimate entity | Key ID validation, strong authentication tags, AAD support | Low |
| **Tampering** | Modification of encrypted data or keys | AES-256-GCM authenticated encryption, envelope integrity | Low |
| **Repudiation** | Denial of cryptographic operations | OpenTelemetry logging, structured error taxonomy | Low |
| **Information Disclosure** | Unauthorized access to sensitive data | Memory zeroization, timing-safe comparisons, no secrets in logs | Medium* |
| **Denial of Service** | Service disruption or resource exhaustion | Input validation, RNG failure detection, memory bounds | Low |
| **Elevation of Privilege** | Gaining unauthorized access levels | Minimal attack surface, fail-secure defaults | Low |

## Security Controls

1. **Cryptographic Controls**: AES-256-GCM, HKDF, secure random generation
2. **Memory Controls**: Native secure_zero() for C targets, best-effort for JS/TS
3. **Input Controls**: Comprehensive validation and sanitization
4. **Monitoring Controls**: Telemetry, structured errors, audit logging
5. **Supply Chain Controls**: SBOM, licensing, CI/CD security

## Memory Zeroization Guarantees

- **C/C++ targets**: Guaranteed via secure_zero() with memset_s/SecureZeroMemory/volatile fallback
- **TypeScript/JavaScript**: Best-effort only - JavaScript cannot guarantee memory zeroization
- **Recommended**: Use WebCrypto non-extractable keys or Node.js KeyObject where possible

## Test Vectors

This SDK includes NIST and Wycheproof test vectors to validate cryptographic correctness and detect tampering attempts.

## Risk Assessment

**Overall Risk Level**: LOW to MEDIUM
- High-assurance cryptographic implementation
- Platform-dependent memory zeroization capabilities  
- Comprehensive testing and validation

*Note: Information disclosure risk is Medium for JavaScript/TypeScript due to language limitations on memory clearing.