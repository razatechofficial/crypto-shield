# Security Policy

## Reporting Security Issues

If you discover a security vulnerability in this SDK, please report it to:

**Email**: security@averox.com  
**Response SLA**: We will acknowledge receipt within 24 hours and provide a detailed response within 5 business days.

### Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 2.0.x   | ✅ Yes            |
| 1.0.x   | ❌ No (deprecated) |

### Embargo Policy

We request that you:
1. Give us reasonable time to investigate and mitigate the issue before public disclosure
2. Avoid privacy violations, destructive behavior, and social engineering
3. Follow coordinated disclosure practices

### What to Include

Please include as much of the following information as possible:
- Type of issue (buffer overflow, SQL injection, cross-site scripting, etc.)
- Full paths of source file(s) related to the manifestation of the issue
- The location of the affected source code (tag/branch/commit or direct URL)
- Any special configuration required to reproduce the issue
- Step-by-step instructions to reproduce the issue
- Proof-of-concept or exploit code (if possible)
- Impact of the issue, including how an attacker might exploit it

## Security Contacts

- **Primary**: security@averox.com
- **Backup**: cto@averox.com

We appreciate your efforts to responsibly disclose security vulnerabilities.