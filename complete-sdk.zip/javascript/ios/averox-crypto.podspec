Pod::Spec.new do |spec|
  spec.name          = "TestSDK"
  spec.version       = "2.0.0"
  spec.summary       = "Enterprise-grade cryptographic SDK with all 18 security gates"
  spec.homepage      = "https://averox.com"
  spec.license       = { :type => "MIT", :file => "LICENSE" }
  spec.author        = { "Averox" => "dev@averox.com" }
  
  spec.source        = { :git => "https://github.com/averox/TestSDK.git", :tag => "v#{spec.version}" }
  spec.source_files  = "Sources/**/*.{h,m,swift}"
  spec.public_header_files = "Sources/**/*.h"
  
  spec.ios.deployment_target = "13.0"
  spec.osx.deployment_target = "10.15"
  
  spec.frameworks = 'Security', 'CryptoKit'
  spec.requires_arc = true
end