# Software Bill of Materials (SBOM)

This directory contains SBOM artifacts for supply chain security compliance.

## Files

- `bom.json` - CycloneDX SBOM in JSON format
- `README.md` - This documentation

## Usage

To verify the SBOM:

```bash
# Validate CycloneDX format
npm install -g @cyclonedx/cdx-cli
cdx validate --input-file sbom/bom.json
```

## Generation

SBOM is automatically generated during SDK build process using:

```bash
npx @cyclonedx/cyclonedx-npm --output-file sbom/bom-node.json
```

This ensures complete dependency tracking for security audits and compliance.
