#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <string.h>

// External function declarations
extern int averox_encrypt(const uint8_t* plaintext, size_t plaintext_len,
                         const uint8_t* key, size_t key_len,
                         const char* key_id,
                         const uint8_t* aad, size_t aad_len,
                         uint8_t** encrypted_output, size_t* output_len);

extern int averox_decrypt(const uint8_t* encrypted_data, size_t encrypted_len,
                         const uint8_t* key, size_t key_len,
                         const uint8_t* aad, size_t aad_len,
                         uint8_t** plaintext_output, size_t* output_len);

// Fuzzing target for libFuzzer
int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
    if (size < 64) return 0; // Need minimum data for key + plaintext + aad
    
    // Fixed key for fuzzing
    const uint8_t key[32] = {0xfe, 0xff, 0xe9, 0x92, 0x86, 0x65, 0x73, 0x1c,
                            0x6d, 0x6a, 0x8f, 0x94, 0x67, 0x30, 0x83, 0x08,
                            0xfe, 0xff, 0xe9, 0x92, 0x86, 0x65, 0x73, 0x1c,
                            0x6d, 0x6a, 0x8f, 0x94, 0x67, 0x30, 0x83, 0x08};
    
    // Split fuzzing input
    size_t aad_len = data[0] % 32; // Limit AAD length
    size_t plaintext_len = (size - aad_len - 1) % 1024; // Limit plaintext length
    
    if (aad_len + plaintext_len + 1 > size) return 0;
    
    const uint8_t* aad = data + 1;
    const uint8_t* plaintext = data + 1 + aad_len;
    
    uint8_t* encrypted = NULL;
    size_t encrypted_len;
    
    // Test encryption with fuzzing input
    int result = averox_encrypt(plaintext, plaintext_len,
                               key, sizeof(key), "fuzz_test",
                               aad_len > 0 ? aad : NULL, aad_len,
                               &encrypted, &encrypted_len);
    
    if (result == 0 && encrypted) {
        // Test round-trip if encryption succeeded
        uint8_t* decrypted = NULL;
        size_t decrypted_len;
        
        averox_decrypt(encrypted, encrypted_len, key, sizeof(key),
                      aad_len > 0 ? aad : NULL, aad_len,
                      &decrypted, &decrypted_len);
        
        if (decrypted) {
            free(decrypted);
        }
        free(encrypted);
    }
    
    return 0;
}