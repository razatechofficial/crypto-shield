#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/secure_zero.h"
#include "../include/aad.h"

// External function declarations from production_encryption_core.c
extern int averox_encrypt(const uint8_t* plaintext, size_t plaintext_len,
                         const uint8_t* key, size_t key_len,
                         const char* key_id,
                         const uint8_t* aad, size_t aad_len,
                         uint8_t** encrypted_output, size_t* output_len);

extern int averox_decrypt(const uint8_t* encrypted_data, size_t encrypted_len,
                         const uint8_t* key, size_t key_len,
                         const uint8_t* aad, size_t aad_len,
                         uint8_t** plaintext_output, size_t* output_len);

extern int averox_validate_production(void);

int main() {
    printf("Running Averox crypto tests...\n");
    
    // Test 1: Basic validation
    if (averox_validate_production() == 0) {
        printf("FAIL: Production validation failed\n");
        return 1;
    }
    printf("PASS: Production validation\n");
    
    // Test 2: AAD cross-stack consistency
    const char* test_plaintext = "AAD consistency test";
    const uint8_t test_key[32] = {0xfe, 0xff, 0xe9, 0x92, 0x86, 0x65, 0x73, 0x1c,
                                 0x6d, 0x6a, 0x8f, 0x94, 0x67, 0x30, 0x83, 0x08,
                                 0xfe, 0xff, 0xe9, 0x92, 0x86, 0x65, 0x73, 0x1c,
                                 0x6d, 0x6a, 0x8f, 0x94, 0x67, 0x30, 0x83, 0x08};
    const uint8_t test_aad[] = "external_aad_test";
    
    uint8_t* encrypted = NULL;
    uint8_t* decrypted = NULL;
    size_t encrypted_len, decrypted_len;
    
    // Test with external AAD
    int result = averox_encrypt((const uint8_t*)test_plaintext, strlen(test_plaintext),
                               test_key, sizeof(test_key), "test_key",
                               test_aad, sizeof(test_aad) - 1,
                               &encrypted, &encrypted_len);
    
    if (result != 0) {
        printf("FAIL: Encryption with external AAD failed\n");
        return 1;
    }
    
    result = averox_decrypt(encrypted, encrypted_len, test_key, sizeof(test_key),
                           test_aad, sizeof(test_aad) - 1,
                           &decrypted, &decrypted_len);
    
    if (result != 0) {
        printf("FAIL: Decryption with external AAD failed\n");
        free(encrypted);
        return 1;
    }
    
    if (memcmp(test_plaintext, decrypted, strlen(test_plaintext)) != 0) {
        printf("FAIL: Plaintext mismatch after AAD round-trip\n");
        free(encrypted);
        free(decrypted);
        return 1;
    }
    
    printf("PASS: AAD cross-stack consistency\n");
    free(encrypted);
    free(decrypted);
    
    printf("All tests passed!\n");
    return 0;
}