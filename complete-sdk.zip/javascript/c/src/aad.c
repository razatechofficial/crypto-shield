#include "aad.h"
#include <string.h>
#include <openssl/crypto.h>

/**
 * AUDIT REQUIREMENT: AAD pass-through helpers for EVP_EncryptUpdate/EVP_DecryptUpdate
 * Implements exact AAD wiring as specified by external auditor
 */

int averox_set_encrypt_aad(EVP_CIPHER_CTX* ctx, const uint8_t* aad, size_t aad_len) {
    if (!ctx) {
        return 0;
    }
    
    if (!aad || aad_len == 0) {
        return 1; // No AAD to set, this is valid
    }
    
    // AUDIT SPECIFICATION: Use EVP_EncryptUpdate with NULL output to set AAD
    int len;
    if (EVP_EncryptUpdate(ctx, NULL, &len, aad, (int)aad_len) != 1) {
        return 0;
    }
    
    return 1;
}

int averox_set_decrypt_aad(EVP_CIPHER_CTX* ctx, const uint8_t* aad, size_t aad_len) {
    if (!ctx) {
        return 0;
    }
    
    if (!aad || aad_len == 0) {
        return 1; // No AAD to set, this is valid
    }
    
    // AUDIT SPECIFICATION: Use EVP_DecryptUpdate with NULL output to set AAD
    int len;
    if (EVP_DecryptUpdate(ctx, NULL, &len, aad, (int)aad_len) != 1) {
        return 0;
    }
    
    return 1;
}

int averox_validate_aad(const uint8_t* aad1, size_t len1, const uint8_t* aad2, size_t len2) {
    if (len1 != len2) {
        return 0;
    }
    
    if (len1 == 0) {
        return 1; // Both empty, valid
    }
    
    if (!aad1 || !aad2) {
        return 0;
    }
    
    // Use constant-time comparison for security
    return CRYPTO_memcmp(aad1, aad2, len1) == 0;
}