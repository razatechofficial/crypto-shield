#ifndef AVEROX_AAD_H
#define AVEROX_AAD_H

#include <openssl/evp.h>
#include <stdint.h>
#include <stddef.h>

/**
 * AUDIT REQUIREMENT: AAD helpers for EVP_EncryptUpdate/EVP_DecryptUpdate
 * Ensures consistent AAD plumbing across TypeScript and C implementations
 */

// Set AAD for encryption before processing plaintext
int averox_set_encrypt_aad(EVP_CIPHER_CTX* ctx, const uint8_t* aad, size_t aad_len);

// Set AAD for decryption before processing ciphertext  
int averox_set_decrypt_aad(EVP_CIPHER_CTX* ctx, const uint8_t* aad, size_t aad_len);

// Validate AAD consistency across encrypt/decrypt operations
int averox_validate_aad(const uint8_t* aad1, size_t len1, const uint8_t* aad2, size_t len2);

#endif // AVEROX_AAD_H